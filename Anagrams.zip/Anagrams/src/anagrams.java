import java.util.*;
import java.io.*;
public class anagrams {
    public static void main(String[] args) {
    ArrayList<String> listofWords = readTXTfile("anagram_words.txt");

    Map<String, ArrayList<String>> anagramMap = mapAnagrams(listofWords);

    cfunction(anagramMap);

    bfunction(anagramMap, listofWords);
}
    static ArrayList<String> readTXTfile(String fileName) {
        ArrayList<String> listOfWords = new ArrayList<>();
        try{
            Scanner scan = new Scanner(new  File(fileName));
            while(scan.hasNext()){
                String currentWord = scan.nextLine();
                listOfWords.add(currentWord);
            }
        }catch(FileNotFoundException e){
            System.err.println("Could not find '"+ fileName+"'");
        }
        return listOfWords;
    }
    static Map<String,ArrayList<String>> mapAnagrams(ArrayList<String> listOfWords){
        Map<String,ArrayList<String>> anagramMap = new HashMap<>();
        for (int i = 0; i < listOfWords.size(); i++) {
            String originalWord = listOfWords.get(i);
            char tempArray[] = originalWord.toCharArray();
            Arrays.sort(tempArray);
            String sortedWord = new String(tempArray);
            if(anagramMap.containsKey(sortedWord)){
                anagramMap.get(sortedWord).add(originalWord);
            }
            else{
                ArrayList<String> newList = new ArrayList<String>();
                newList.add(originalWord);
                anagramMap.put(sortedWord,newList);
            }
        }
        return anagramMap;
    }
    static void cfunction(Map<String,ArrayList<String>> anagramMap){
        Scanner scan = new Scanner(System.in);
        System.out.println("Input a word to see its anagrams. Type 's' to stop.");
        String userWord = scan.next();
        while(!userWord.equals("s")&&!userWord.equals("S")){
            char tempArray[] = userWord.toCharArray();
            Arrays.sort(tempArray);
            String sortedUserWord = new String(tempArray);
            if(anagramMap.containsKey(sortedUserWord)){
                String outputString = "The anagrams of "+ userWord+" are:\n";
                for (int i = 0; i < anagramMap.get(sortedUserWord).size(); i++) {
                    if(!userWord.equals(anagramMap.get(sortedUserWord).get(i))){
                        outputString += anagramMap.get(sortedUserWord).get(i)+"\n";
                    }
                }
                System.out.println(outputString);
            }
            else{
                System.out.println("The map didn't contain any anagrams of that word");
            }
            userWord = scan.next();
        }
        System.out.println("Done");
    }
    static void bfunction(Map<String,ArrayList<String>> anagramMap, ArrayList<String> listOfWords){
        System.out.println("Here is a randomly chosen word. Type a word to see if it is an anagram. Type 's' to stop ");
        Scanner scan = new Scanner(System.in);
        String userInput = "";
        while(!userInput.equals("s")&&!userInput.equals("S")) {
            Random generator = new Random();
            int max = listOfWords.size();
            String randomWord = listOfWords.get((int) ((Math.random() * (max - 0)) + 0));
            System.out.println(randomWord);
            char tempArray[] = randomWord.toCharArray();
            Arrays.sort(tempArray);
            String sortedRandomWord = new String(tempArray);
            userInput = scan.next();
            char tempArray2[] = userInput.toCharArray();
            Arrays.sort(tempArray2);
            String sortedUserInput = new String(tempArray2);
            if(userInput.equals("s")||userInput.equals("S")){
                break;
            }
            else if (sortedUserInput.equals(sortedRandomWord)) {
                System.out.println("Yes, '" + userInput + "' is an anagram of " + randomWord);
            } else {
                System.out.println("No, '" + userInput + "' is not an anagram of " + randomWord);
            }
            System.out.println("Here's another word:");
        }
        System.out.println("done");
    }
}
